
// You can write more code here
		var counter = 0
		var power = 1
		var batPower = 0
		var upgradeCost = 5
		var batCost = 10

/* START OF COMPILED CODE */

class Level extends Phaser.Scene {

	constructor() {
		super("Level");

		/* START-USER-CTR-CODE */
		// Write your code here.
		/* END-USER-CTR-CODE */
	}

	/** @returns {void} */
	editorCreate() {

		// firstSelection
		const firstSelection = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);

		// Dino Text
		const dino_Text = this.add.container(133, 61);

		// pageCounter
		const pageCounter = this.add.text(513, 121, "", {});
		pageCounter.setInteractive(new Phaser.Geom.Rectangle(0, 0, 459, 33), Phaser.Geom.Rectangle.Contains);
		pageCounter.setOrigin(0.5, 0.5);
		pageCounter.text = "0";
		pageCounter.setStyle({ "fontFamily": "Arial", "fontSize": "32px" });
		dino_Text.add(pageCounter);

		// onAwakeScript_1
		const onAwakeScript_1 = new OnAwakeScript(pageCounter);

		// fadeActionScript
		const fadeActionScript = new FadeActionScript(onAwakeScript_1);

		// onPointerDownScript_1
		const onPointerDownScript_1 = new OnPointerDownScript(pageCounter);

		// pushActionScript_1
		new PushActionScript(onPointerDownScript_1);

		// normal_Attack
		const normal_Attack = this.add.image(524, 457, "Normal_Attack");
		normal_Attack.setInteractive(new Phaser.Geom.Rectangle(0, 0, 290, 432), Phaser.Geom.Rectangle.Contains);
		normal_Attack.scaleX = 0.5;
		normal_Attack.scaleY = 0.5;
		dino_Text.add(normal_Attack);

		// onPointerDownScript_2
		const onPointerDownScript_2 = new OnPointerDownScript(normal_Attack);

		// pushActionScript_2
		new PushActionScript(onPointerDownScript_2);

		// damage
		const damage = this.add.image(809, 441, "Damage");
		damage.scaleX = 0.5;
		damage.scaleY = 0.5;
		dino_Text.add(damage);

		// onPointerDownScript
		const onPointerDownScript = new OnPointerDownScript(damage);

		// pushActionScript
		new PushActionScript(onPointerDownScript);

		// batCard
		const batCard = this.add.image(208, 440, "BatCard");
		batCard.scaleX = 0.5;
		batCard.scaleY = 0.5;
		dino_Text.add(batCard);

		// onPointerDownScript_8
		const onPointerDownScript_8 = new OnPointerDownScript(batCard);

		// pushActionScript_8
		new PushActionScript(onPointerDownScript_8);

		// damageText
		const damageText = this.add.text(653, 654, "", {});
		damageText.setInteractive(new Phaser.Geom.Rectangle(0, 0, 459, 33), Phaser.Geom.Rectangle.Contains);
		damageText.setOrigin(0.5, 0.5);
		damageText.text = "damage: 1";
		damageText.setStyle({ "fontFamily": "Arial", "fontSize": "32px" });

		// onAwakeScript
		const onAwakeScript = new OnAwakeScript(damageText);

		// fadeActionScript_1
		const fadeActionScript_1 = new FadeActionScript(onAwakeScript);

		// onPointerDownScript_3
		const onPointerDownScript_3 = new OnPointerDownScript(damageText);

		// pushActionScript_3
		new PushActionScript(onPointerDownScript_3);

		// upgradeInfo
		const upgradeInfo = this.add.text(947, 644, "", {});
		upgradeInfo.setInteractive(new Phaser.Geom.Rectangle(0, 0, 459, 33), Phaser.Geom.Rectangle.Contains);
		upgradeInfo.setOrigin(0.5, 0.5);
		upgradeInfo.text = "increase damage by 1";
		upgradeInfo.setStyle({ "fontFamily": "Arial", "fontSize": "32px" });

		// onAwakeScript_2
		const onAwakeScript_2 = new OnAwakeScript(upgradeInfo);

		// fadeActionScript_2
		const fadeActionScript_2 = new FadeActionScript(onAwakeScript_2);

		// onPointerDownScript_4
		const onPointerDownScript_4 = new OnPointerDownScript(upgradeInfo);

		// pushActionScript_4
		new PushActionScript(onPointerDownScript_4);

		// upgradeCost
		const upgradeCost = this.add.text(947, 685, "", {});
		upgradeCost.setInteractive(new Phaser.Geom.Rectangle(0, 0, 459, 33), Phaser.Geom.Rectangle.Contains);
		upgradeCost.setOrigin(0.5, 0.5);
		upgradeCost.setStyle({ "fontFamily": "Arial", "fontSize": "32px" });

		// onAwakeScript_3
		const onAwakeScript_3 = new OnAwakeScript(upgradeCost);

		// fadeActionScript_3
		const fadeActionScript_3 = new FadeActionScript(onAwakeScript_3);

		// onPointerDownScript_5
		const onPointerDownScript_5 = new OnPointerDownScript(upgradeCost);

		// pushActionScript_5
		new PushActionScript(onPointerDownScript_5);

		// batInfo
		const batInfo = this.add.text(349, 651, "", {});
		batInfo.setInteractive(new Phaser.Geom.Rectangle(0, 0, 459, 33), Phaser.Geom.Rectangle.Contains);
		batInfo.setOrigin(0.5, 0.5);
		batInfo.text = "increase dps by 1";
		batInfo.setStyle({ "fontFamily": "Arial", "fontSize": "32px" });

		// onAwakeScript_4
		const onAwakeScript_4 = new OnAwakeScript(batInfo);

		// fadeActionScript_4
		const fadeActionScript_4 = new FadeActionScript(onAwakeScript_4);

		// onPointerDownScript_6
		const onPointerDownScript_6 = new OnPointerDownScript(batInfo);

		// pushActionScript_6
		new PushActionScript(onPointerDownScript_6);

		// batCost
		const batCost = this.add.text(348, 699, "", {});
		batCost.setInteractive(new Phaser.Geom.Rectangle(0, 0, 459, 33), Phaser.Geom.Rectangle.Contains);
		batCost.setOrigin(0.5, 0.5);
		batCost.setStyle({ "fontFamily": "Arial", "fontSize": "32px" });

		// onAwakeScript_5
		const onAwakeScript_5 = new OnAwakeScript(batCost);

		// fadeActionScript_5
		const fadeActionScript_5 = new FadeActionScript(onAwakeScript_5);

		// onPointerDownScript_7
		const onPointerDownScript_7 = new OnPointerDownScript(batCost);

		// pushActionScript_7
		new PushActionScript(onPointerDownScript_7);

		// dinoPrefab
		const dinoPrefab = new DinoPrefab(this, 240, 559);
		this.add.existing(dinoPrefab);

		// prefabStar_2
		const prefabStar_2 = new PrefabStar(this, 848, 118);
		this.add.existing(prefabStar_2);

		// idlestars
		const idlestars = new PrefabStar(this, 889, 312);
		this.add.existing(idlestars);

		// prefabStar
		const prefabStar = new PrefabStar(this, 414.98292216191044, 205.09677428565044);
		this.add.existing(prefabStar);

		// prefabStar_1
		const prefabStar_1 = new PrefabStar(this, 1098, 180);
		this.add.existing(prefabStar_1);

		// lists
		const stars = [prefabStar_2, idlestars, prefabStar, prefabStar_1];

		// collider
		this.physics.add.collider(dinoPrefab, stars, this.pickStar, undefined, this);

		// fadeActionScript (prefab fields)
		fadeActionScript.fadeDirection = "FadeIn";

		// fadeActionScript (components)
		const fadeActionScriptDurationConfigComp = new DurationConfigComp(fadeActionScript);
		fadeActionScriptDurationConfigComp.duration = 1500;

		// fadeActionScript_1 (prefab fields)
		fadeActionScript_1.fadeDirection = "FadeIn";

		// fadeActionScript_1 (components)
		const fadeActionScript_1DurationConfigComp = new DurationConfigComp(fadeActionScript_1);
		fadeActionScript_1DurationConfigComp.duration = 1500;

		// fadeActionScript_2 (prefab fields)
		fadeActionScript_2.fadeDirection = "FadeIn";

		// fadeActionScript_2 (components)
		const fadeActionScript_2DurationConfigComp = new DurationConfigComp(fadeActionScript_2);
		fadeActionScript_2DurationConfigComp.duration = 1500;

		// fadeActionScript_3 (prefab fields)
		fadeActionScript_3.fadeDirection = "FadeIn";

		// fadeActionScript_3 (components)
		const fadeActionScript_3DurationConfigComp = new DurationConfigComp(fadeActionScript_3);
		fadeActionScript_3DurationConfigComp.duration = 1500;

		// fadeActionScript_4 (prefab fields)
		fadeActionScript_4.fadeDirection = "FadeIn";

		// fadeActionScript_4 (components)
		const fadeActionScript_4DurationConfigComp = new DurationConfigComp(fadeActionScript_4);
		fadeActionScript_4DurationConfigComp.duration = 1500;

		// fadeActionScript_5 (prefab fields)
		fadeActionScript_5.fadeDirection = "FadeIn";

		// fadeActionScript_5 (components)
		const fadeActionScript_5DurationConfigComp = new DurationConfigComp(fadeActionScript_5);
		fadeActionScript_5DurationConfigComp.duration = 1500;

		this.pageCounter = pageCounter;
		this.normal_Attack = normal_Attack;
		this.damage = damage;
		this.batCard = batCard;
		this.damageText = damageText;
		this.upgradeInfo = upgradeInfo;
		this.upgradeCost = upgradeCost;
		this.batInfo = batInfo;
		this.batCost = batCost;
		this.dinoPrefab = dinoPrefab;
		this.firstSelection = firstSelection;
		this.stars = stars;

		this.events.emit("scene-awake");
	}

	/** @type {Phaser.GameObjects.Text} */
	pageCounter;
	/** @type {Phaser.GameObjects.Image} */
	normal_Attack;
	/** @type {Phaser.GameObjects.Image} */
	damage;
	/** @type {Phaser.GameObjects.Image} */
	batCard;
	/** @type {Phaser.GameObjects.Text} */
	damageText;
	/** @type {Phaser.GameObjects.Text} */
	upgradeInfo;
	/** @type {Phaser.GameObjects.Text} */
	upgradeCost;
	/** @type {Phaser.GameObjects.Text} */
	batInfo;
	/** @type {Phaser.GameObjects.Text} */
	batCost;
	/** @type {DinoPrefab} */
	dinoPrefab;
	/** @type {Phaser.Input.Keyboard.Key} */
	firstSelection;
	/** @type {PrefabStar[]} */
	stars;

	/* START-USER-CODE */

	// Write more your code here

	create() {

		this.editorCreate();
		setInterval(function () {
			counter = counter + this.batPower
		}, 1000)

		this.normal_Attack.on("pointerdown", () => {
			counter = counter + power
		})

		this.damage.on("pointerdown", function() {
			if (counter >= upgradeCost) {
				power++
				counter = counter - upgradeCost
				upgradeCost = upgradeCost * 2
			}
		})

		this.batCard.on("pointerdown", function() {
			if (counter >= batCost) {
				batPower++
				counter = counter - batCost
				batCost = batCost * 2
			}
		})


	}

	awake() {
	}

	update() {
		// if (this.firstSelection.isDown) {
		// 	counter++
		// }
		this.pageCounter.text = counter
		this.damageText.text = "damage: " + power
		this.batCost.text = "Cost: " + batCost
		this.upgradeCost.text = "Cost: " + upgradeCost
	}

	pickStar(eagle, stars) {
		console.log("BALLLS")
		counter = counter + 1;
		stars.destroy();


	}

	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
