
// You can write more code here

/* START OF COMPILED CODE */

class MovementScript extends ScriptNode {

	constructor(parent) {
		super(parent);

		/* START-USER-CTR-CODE */
		// Write your code here.
		/* END-USER-CTR-CODE */
	}

	/** @type {number} */
	velocity = 1;

	/* START-USER-CODE */

	// Write your code here.

	update() {
		if (this.velocity < 0) {
			this.velocity = 0
		}
		if (this.parent.speedUp.isDown && this.velocity <= 5) {
			this.velocity += 0.01
		}
		if (this.parent.slowDown.isDown && this.velocity > 0) {
			this.velocity -= 0.01
		}
		if (this.parent.upKey.isDown) {
			this.parent.body.setVelocityY(-this.velocity * 100)
		}
		if (this.parent.downKey.isDown) {
			this.parent.body.setVelocityY(this.velocity * 100)
		}

		if (this.parent.rightKey.isDown) {
			this.parent.body.setVelocityX(this.velocity * 100)
			this.parent.scaleX = -2
		}
		if (this.parent.leftKey.isDown) {
			this.parent.body.setVelocityX(-this.velocity * 100)
			this.parent.scaleX = 2
		}
		console.log(this.velocity)
	}

	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
