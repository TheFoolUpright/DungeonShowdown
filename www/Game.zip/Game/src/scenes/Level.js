
// You can write more code here
var counter = 0

/* START OF COMPILED CODE */

class Level extends Phaser.Scene {

	constructor() {
		super("Level");

		/* START-USER-CTR-CODE */
		// Write your code here.

		/* END-USER-CTR-CODE */
	}

	/** @returns {void} */
	editorCreate() {

		// returnKey
		const returnKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);

		// spaceKey
		const spaceKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);

		// counterText
		const counterText = this.add.text(636, 515, "", {});
		counterText.name = "counterText";
		counterText.setOrigin(0.5, 0.5);
		counterText.text = "This is my fruit!";
		counterText.setStyle({ "fontFamily": "Arial", "fontSize": "30px" });

		// onAwakeScript_1
		const onAwakeScript_1 = new OnAwakeScript(counterText);

		// fadeActionScript
		const fadeActionScript = new FadeActionScript(onAwakeScript_1);

		// max_Health
		const max_Health = new PrefabCard(this, 641, 238);
		this.add.existing(max_Health);

		// dinoPrefab
		const dinoPrefab = new DinoPrefab(this, 281, 292);
		this.add.existing(dinoPrefab);

		// idlestars
		const idlestars = new PrefabStar(this, 914, 332);
		this.add.existing(idlestars);

		// prefabStar
		const prefabStar = new PrefabStar(this, 125, 511);
		this.add.existing(prefabStar);

		// prefabStar_1
		const prefabStar_1 = new PrefabStar(this, 1187, 474);
		this.add.existing(prefabStar_1);

		// prefabStar_2
		const prefabStar_2 = new PrefabStar(this, 1147, 96);
		this.add.existing(prefabStar_2);

		// prefabStar_3
		const prefabStar_3 = new PrefabStar(this, 496, 572);
		this.add.existing(prefabStar_3);

		// lists
		const stars = [prefabStar_3, prefabStar_2, prefabStar_1, prefabStar, idlestars];

		// collider
		this.physics.add.overlap(dinoPrefab, stars, this.PickUpStar, undefined, this);

		// fadeActionScript (prefab fields)
		fadeActionScript.fadeDirection = "FadeIn";

		// fadeActionScript (components)
		const fadeActionScriptDurationConfigComp = new DurationConfigComp(fadeActionScript);
		fadeActionScriptDurationConfigComp.duration = 1500;

		this.counterText = counterText;
		this.max_Health = max_Health;
		this.returnKey = returnKey;
		this.spaceKey = spaceKey;
		this.stars = stars;

		this.events.emit("scene-awake");
	}

	/** @type {Phaser.GameObjects.Text} */
	counterText;
	/** @type {PrefabCard} */
	max_Health;
	/** @type {Phaser.Input.Keyboard.Key} */
	returnKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	spaceKey;
	/** @type {PrefabStar[]} */
	stars;

	/* START-USER-CODE */

	// Write more your code here

	PickUpStar (eagle, star){
		counter = counter + 1
		this.counterText.text = counter
		star.destroy();
	}	

	create() {

		this.editorCreate();

		this.max_Health.on("pointerdown", () => {
			counter = counter + 1
		});

	}

	update() {
		if (this.spaceKey.isDown) {
			counter = counter + 1
		}
		this.counterText.text = counter

	}

	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
