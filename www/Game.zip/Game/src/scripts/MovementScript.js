
// You can write more code here

/* START OF COMPILED CODE */

class MovementScript extends ScriptNode {

	constructor(parent) {
		super(parent);

		// dKey
		const dKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);

		// aKey
		const aKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);

		// wKey
		const wKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);

		// sKey
		const sKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);

		this.dKey = dKey;
		this.aKey = aKey;
		this.wKey = wKey;
		this.sKey = sKey;

		/* START-USER-CTR-CODE */
		// Write your code here.
		/* END-USER-CTR-CODE */
	}

	/** @type {Phaser.Input.Keyboard.Key} */
	dKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	aKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	wKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	sKey;
	/** @type {number} */
	velocity = 300;

	/* START-USER-CODE */

	// Write your code here.
	update(){
		if (this.parent.aKey.isDown) {
			this.parent.body.setVelocityX(-this.velocity)
			//this.parent.x -= this.velocity
			this.parent.flipX = false
		}
		if (this.parent.dKey.isDown) {
			this.parent.body.setVelocityX(this.velocity)
			//this.parent.x += this.velocity
			this.parent.flipX = true
		}
		if (this.parent.wKey.isDown) {
			this.parent.body.setVelocityY(-this.velocity)
			//this.parent.y -= this.velocity
		}
		if (this.parent.sKey.isDown) {
			this.parent.body.setVelocityY(this.velocity)
			//this.parent.y += this.velocity
		}

	}

	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
