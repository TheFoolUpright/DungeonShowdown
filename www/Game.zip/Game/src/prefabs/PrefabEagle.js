
// You can write more code here

/* START OF COMPILED CODE */

class PrefabEagle extends Phaser.GameObjects.Sprite {

	constructor(scene, x, y, texture, frame) {
		super(scene, x ?? 0, y ?? 0, texture || "eagle-spritesheet", frame ?? 0);

		this.scaleX = 5;
		this.scaleY = 5;
		this.play("Idleeagle-spritesheet");

		// movementScript
		new MovementScript(this);

		// dKey
		const dKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);

		// aKey
		const aKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);

		// wKey
		const wKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);

		// sKey
		const sKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);

		this.dKey = dKey;
		this.aKey = aKey;
		this.wKey = wKey;
		this.sKey = sKey;

		/* START-USER-CTR-CODE */
		// Write your code here.
		/* END-USER-CTR-CODE */
	}

	/** @type {Phaser.Input.Keyboard.Key} */
	dKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	aKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	wKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	sKey;

	/* START-USER-CODE */

	// Write your code here.

	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
