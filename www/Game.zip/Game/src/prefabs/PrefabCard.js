
// You can write more code here

/* START OF COMPILED CODE */

class PrefabCard extends Phaser.GameObjects.Image {

	constructor(scene, x, y, texture, frame) {
		super(scene, x ?? 0, y ?? 0, texture || "Max Health", frame);

		this.setInteractive(new Phaser.Geom.Rectangle(0, 0, 300, 450), Phaser.Geom.Rectangle.Contains);

		// onPointerDownScript_2
		const onPointerDownScript_2 = new OnPointerDownScript(this);

		// pushActionScript_2
		new PushActionScript(onPointerDownScript_2);

		/* START-USER-CTR-CODE */
		// Write your code here.
		/* END-USER-CTR-CODE */
	}

	/* START-USER-CODE */

	// Write your code here.

	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
