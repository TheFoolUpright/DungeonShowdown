
// You can write more code here

/* START OF COMPILED CODE */

class DinoPrefab extends Phaser.GameObjects.Sprite {

	constructor(scene, x, y, texture, frame) {
		super(scene, x ?? 0, y ?? 0, texture || "eagle-spritesheet", frame ?? 0);

		this.scaleX = 5;
		this.scaleY = 5;
		scene.physics.add.existing(this, false);
		this.body.drag.x = 100;
		this.body.drag.y = 100;
		this.body.setSize(40, 41, false);
		this.play("Idleeagle-spritesheet");

		// movementScript_1
		const movementScript_1 = new MovementScript(this);

		// onAwakeScript_1
		const onAwakeScript_1 = new OnAwakeScript(this);

		// moveInSceneActionScript_1
		const moveInSceneActionScript_1 = new MoveInSceneActionScript(onAwakeScript_1);

		// onPointerDownScript_1
		const onPointerDownScript_1 = new OnPointerDownScript(this);

		// pushActionScript_1
		new PushActionScript(onPointerDownScript_1);

		// dKey
		const dKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);

		// aKey
		const aKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);

		// wKey
		const wKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);

		// sKey
		const sKey = this.scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);

		// moveInSceneActionScript_1 (prefab fields)
		moveInSceneActionScript_1.from = "TOP";

		// moveInSceneActionScript_1 (components)
		const moveInSceneActionScript_1DurationConfigComp = new DurationConfigComp(moveInSceneActionScript_1);
		moveInSceneActionScript_1DurationConfigComp.duration = 1000;

		this.movementScript_1 = movementScript_1;
		this.dKey = dKey;
		this.aKey = aKey;
		this.wKey = wKey;
		this.sKey = sKey;

		/* START-USER-CTR-CODE */
		// Write your code here.
		/* END-USER-CTR-CODE */
	}

	/** @type {MovementScript} */
	movementScript_1;
	/** @type {Phaser.Input.Keyboard.Key} */
	dKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	aKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	wKey;
	/** @type {Phaser.Input.Keyboard.Key} */
	sKey;

	/* START-USER-CODE */

	// Write your code here.

	/* END-USER-CODE */
}

/* END OF COMPILED CODE */

// You can write more code here
